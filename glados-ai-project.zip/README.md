# Real-Life GLaDOS AI System
A fully articulated animatronic with sarcastic AI, object detection, voice synthesis, and persistent memory.